﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveZCube : MonoBehaviour
{
    float speed=0.0f;
    bool isForward = true;
    public GameObject surface;
    void Start()
    {
        
    }

    
    void Update()
    {
        speed = Random.Range(1.0f, 20.0f);


        if (transform.position.z < 25.0f && isForward == true)
        {
            transform.Translate(Vector3.forward * Time.deltaTime * speed);
        }
        else if (transform.position.z > surface.transform.position.z+2.5f && isForward == false) 
            {
            transform.Translate(Vector3.forward * Time.deltaTime * -speed);

            
        }
        else 
        {
            isForward = !isForward;
        }

       
    }
    
}
